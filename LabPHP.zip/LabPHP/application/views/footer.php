<style>
        /*ESTILOS PARA EL FOOTER */
        .af{
        font-family: 'Sen', sans-serif;
        color: #fa7f72;
    }
    .conteinerF {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
    }

    .c1F {
        width: 20%;
        padding: 1%;
        margin: 1%;
    }
    
    .c2F {
        width: 20%;
        padding: 1%;
        margin: 1%;
    }
    i{
        height:50px; 
        width: auto;
        opacity: 50%;
    }
    </style>

<footer>
            <div class="conteinerF">
                <div class="c1F">
                    <img src="https://res.cloudinary.com/djiek0hdx/image/upload/v1652475444/74717_lvmzx5.png" height="40px" width="auto" style="opacity: 50%; margin: 1%;">
                </div>
                <div class="c2F">
                    <img src="https://res.cloudinary.com/djiek0hdx/image/upload/v1652475369/te_lo_llevo-removebg-preview_-_copia_s12jso.png" height="50px" width="auto" style="margin-left: 20%;">
                </div>
            </div>

            <div class="conteinerF">
                <div class="c1F">
                    <i class="gg-phone"></i>
                </div>
                <div class="c2F">
                    <label style="color: black; opacity: 50%;"> 4342 1111</label>
                </div>
                <div class="c1F">
                    <label style="color: black; opacity: 50%;">|</label>
                </div>
                <div class="c2F">
                    <label style="color: black; opacity: 50%;">+598 92 111 111</label>
                </div>
            </div>

            <div class="conteinerF">
                <div class="c1F">
                    <i class="gg-mail"></i>
                </div>
                <div class="c2F">
                    <label style="color: black; opacity: 50%;">atencioncliente@gmail.com</label>
                </div>
                <div class="c1F">
                    <label style="color: black; opacity: 50%;">|</label>
                </div>
                <div class="c2F">
                    <label style="color: black; opacity: 50%;">telollevolabphp@gmail.com</label>
                </div>
            </div>

        </footer>      
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    </body>
</html>